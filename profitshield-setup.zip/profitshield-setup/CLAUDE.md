# CLAUDE.md

This file is the project-level context for Claude Code working on ProfitShield. Read it fully at the start of every session before taking any action.

## Product

**ProfitShield** — the financial intelligence platform for Amazon 1P vendors. Think "CFO dashboard for Amazon."

ProfitShield ingests every Amazon vendor deduction — shortages, chargebacks, SIPP/SIOC compliance fines, co-op advertising charges, markdown allowances, price claims, freight allowances — reconciles them against POs, invoices, shipments, and active co-op agreements, and surfaces which deductions are disputable with evidence pre-attached. The product tracks dispute status, recovery rates, and preserves financial history beyond the 9 months Vendor Central retains.

Target outcome: a vendor CFO opens ProfitShield once a day instead of hunting through Vendor Central reports, knows their ASIN-level P&L net of Amazon fees, knows which deductions to dispute today before the 30-day window closes, and sees recovery-rate trend lines over time.

This product is being built and operated by RefundsManager, the operator's ~13-year-old Amazon-approved vendor reimbursement recovery service. ProfitShield is the product-ization of that manual-service expertise.

## Customer

Amazon 1P vendors (companies that sell **to** Amazon, not on Amazon Marketplace). Mid-market primarily — $5M to $200M annual Amazon GMV. Typical buyer is the CFO, Director of Finance, or VP of Operations at a consumer brand. They are not technical users.

Initial launch customers come from the existing RefundsManager book of business — vendors who already have SP-API authorization with us for the manual recovery service and who trust the brand. This is the Trojan horse advantage: ProfitShield is an upsell, not a net-new sale.

## Operator

Solo operator (Chaim, founder of RefundsManager). No engineering team. All code is written by Claude Code; the operator reviews, tests, and deploys. Jacob Vatch leads operations for the existing manual-recovery business — he may eventually use ProfitShield's dispute workflow but does not work on this codebase.

## Non-Negotiable Principles

These rules override any technical preference or "best practice" that contradicts them. If a proposed change violates one of these, stop and ask.

1. **Idempotency everywhere.** Every ingestion job, every reconciliation pass, every webhook handler must be safely re-runnable. Vendor Central reports occasionally double-deliver the same rows; your code must handle that without creating phantom deductions.
2. **Financial data integrity is sacred.** Dollar amounts must never be lost, miscounted, or silently truncated. Every sum reconciles to source-of-truth (Amazon's remittance). If a row cannot be parsed with confidence, store it unparsed and flag for review — do NOT guess.
3. **Simple beats clever.** The operator must be able to debug any component at 2am with Claude's help.
4. **One service, one responsibility.** No god-functions.
5. **Security by default.** No public IPs on data stores. No static credentials in code. All secrets in AWS Secrets Manager. IAM roles for service auth.
6. **Observability before features.** Every new component ships with logging, metrics, and a failure-mode alert.
7. **Test in staging first, always.** No changes go directly to production. Promote via CI/CD.
8. **Small surface area.** When in doubt, don't build the feature.

## Architecture

### Cloud: AWS
This product shares AWS infrastructure with the operator's other cloud product (RefundsManager Cloud DD+7 tracker). Infrastructure layer is shared; application layer is isolated.

- **AWS account:** 301545512136 (shared).
- **Region:** us-east-1.
- **VPC:** vpc-0ba16c2c4c82478e4 (shared — CIDR 10.0.0.0/16, private/public subnets across 2 AZs).
- **Aurora cluster:** rm-dev-aurora (shared — Aurora PostgreSQL Serverless v2, engine version 16).
- **Secrets Manager:** shared, with product-specific prefix `profitshield/{env}/*`.

### What's ISOLATED to ProfitShield
- **Separate database inside the shared Aurora cluster:** `profitshield` (dev), later `profitshield_staging` and `profitshield_prod`. Other product's database is `refundsmanager_cloud`; no cross-database queries, no shared tables, no data sharing across databases.
- **Separate GitHub repo:** this one.
- **Separate Lambdas** with tag `Project=profitshield`.
- **Separate CloudWatch log groups** prefixed `/aws/lambda/profitshield-*`.
- **Separate Secrets** under `profitshield/*` prefix.

### What's SHARED across products
- AWS account, IAM, billing, GuardDuty, Config.
- VPC, subnets, security groups (subnet ownership is shared; SGs are per-product).
- Aurora cluster (one physical cluster, multiple logical databases).
- LWA client ID and client secret (Amazon SP-API app credentials). The app itself is shared; per-vendor refresh tokens are stored in this product's own secret namespace.
- Clerk auth tenant (one Clerk app, products distinguished by user metadata).

### Services (this product's footprint)
- **Database:** logical database `profitshield` inside shared Aurora cluster. Multi-tenant with Row-Level Security keyed on `vendor_id`.
- **Async compute:** AWS Lambda (Python 3.12). Triggered by EventBridge schedules or SQS queues.
- **API compute:** Next.js API routes on AWS Amplify Hosting.
- **Frontend:** Next.js 15 (App Router) deployed to AWS Amplify Hosting. TypeScript. Tailwind CSS.
- **Auth:** Clerk.
- **Queues:** Amazon SQS. Dead-letter queues on every queue.
- **Scheduling:** Amazon EventBridge Scheduler.
- **Report ingestion:** Amazon S3 bucket `profitshield-{env}-reports-ingest` for Vendor Central report file staging. Lambdas read from S3, parse, write to Postgres.
- **Email:** SendGrid.
- **SMS:** Twilio.
- **Error tracking:** Sentry.
- **Logs:** CloudWatch. 90-day hot retention, archive to S3 for 2 years.

### SP-API
- **Reuses the existing RefundsManager SP-API developer application.** Same LWA client ID and client secret stored in shared Secrets Manager under `refundsmanager-cloud/{env}/sp-api/app-credentials`. Do not register a new app.
- **Per-vendor refresh tokens** stored in this product's own secret namespace: `profitshield/{env}/sp-api/vendor/{vendor_id}/refresh-token`.
- **User-Agent required on every SP-API call:** `ProfitShield/1.0 (cloud)` — distinguishes traffic from on-prem RefundsManager, DD+7 cloud product, and this product in Amazon's request logs.
- **Attribution fields required in every log line:** `source_system="profitshield"`, `vendor_id`, `endpoint`, `x-amzn-RequestId`, `component`.
- **Defensive rate-limit handling:** shared LWA credentials mean shared rate-limit buckets with on-prem. Back off aggressively on 429s. Circuit breaker at 3 consecutive 429s per seller per endpoint.

### Vendor Central Data Sources
Amazon's vendor data is a mix of APIs and report files. Plan for both.

**APIs (preferred):**
- `getPurchaseOrders` (Vendor Retail Procurement API) — POs.
- `submitAcknowledgement` — PO confirmation.
- `getPurchaseOrderItems` — PO line items.
- Vendor Direct Fulfillment APIs — only relevant if a vendor ships direct to customer (many don't).
- Reports API (Vendor reports endpoint) — pulls report files as structured data.

**Vendor Central Reports (fallback / primary for many deduction types):**
- Shortage report.
- Chargeback report.
- Co-op and accrual backup.
- Price claim report.
- Remittance details.
- Pricing error / flex allowance documents.

Some of these are available via SP-API Reports; others require Vendor Central UI download. Design the ingestion layer to handle both: Lambda pulls from SP-API where available, S3 upload fallback for reports that must come from the UI.

Schemas drift. Vendor Central reports change column names and formats without notice. Every parser must be defensive, log unknown columns, and fail loudly rather than silently drop data.

### Core Data Model (Postgres)

Primary tables in the `profitshield` database:

- `vendors` — vendor account metadata, one row per authorized Amazon vendor account.
- `vendor_users` — mapping of Clerk users to vendors (many-to-many for parent companies with multiple vendor accounts).
- `sp_api_cursors` — per-vendor, per-endpoint cursor position.
- `purchase_orders` — PO header data.
- `purchase_order_items` — PO line items.
- `invoices` — vendor-submitted invoices against POs.
- `shipments` — ASN/shipment records, joined to carrier events later.
- `remittances` — Amazon's weekly/biweekly payment remittances.
- `remittance_lines` — line-level detail within each remittance.
- `shortages` — claim-level shortage records.
- `chargebacks` — compliance/operational chargebacks (SIPP, SIOC, OTIF, ASN accuracy, etc.).
- `coop_agreements` — active co-op advertising agreements, with effective dates.
- `coop_charges` — individual co-op charges to reconcile against agreements.
- `price_claims` — price claim deductions and protection events.
- `freight_allowances` — freight allowance charges.
- `disputes` — disputes filed by the vendor (or by ops team on vendor's behalf), with status, filing date, outcome, recovery amount.
- `recovery_events` — money actually returned to the vendor, for recovery-rate tracking.
- `alerts` — alert log.
- `alert_preferences` — per-vendor thresholds and channels.
- `report_ingestions` — log of every report file ingested, checksum, row count, parse outcome.
- `parse_failures` — rows from report files that failed to parse, kept for manual review.

All tables have `created_at`, `updated_at` triggers. All tenant-scoped tables have RLS policies on `vendor_id`. All writes go through stored functions or parameterized queries.

### Reconciliation Engine (the heart of the product)

This is where ProfitShield's value gets created. The engine runs after each ingestion pass and answers:

1. For each shortage claim: does the PO exist? Was the shipment delivered? Does the ASN match the PO? Is there a BOL? Amazon's claim may be disputable if any link is broken.
2. For each chargeback: what's the specific code? Is the alleged defect documented? Is the 30-day dispute window still open?
3. For each co-op charge: is there an active agreement that authorizes it? Is the rate correct? Is the charge within the agreement's effective dates?
4. For each remittance: does the net payment reconcile to (invoices - deductions)? Any silent ghost deductions?

The engine produces `dispute_candidates` — rows flagged as potentially recoverable, with evidence references attached (which PO, which shipment, which agreement). These surface on the dashboard and optionally feed the ops team's filing workflow.

### Alert Types (v1)
- **DisputeWindowClosing:** deduction is X days from the 30-day window closing and no dispute has been filed.
- **AnomalousDeduction:** deduction value is >2σ above trailing 90-day average for that category.
- **UnauthorizedCoop:** co-op charge with no matching active agreement.
- **StaleCoopAgreement:** agreement expired but charges still coming in.
- **ShortageWithoutPODMismatch:** Amazon claims shortage but ASN and BOL show full delivery.
- **RemittanceMismatch:** remittance net doesn't reconcile to invoices minus deductions.
- **ReportIngestionFailure:** expected report didn't arrive in expected window.

Every alert type has a SQL/query definition, notification template, and runbook.

## Repository Structure

```
/
├── CLAUDE.md                   (this file)
├── README.md                   (minimal, public-facing)
├── /infra                      (Terraform)
│   ├── environments/
│   │   ├── dev/
│   │   ├── staging/
│   │   └── prod/
│   └── modules/
│       ├── database/           (database-within-cluster, not a new cluster)
│       ├── lambdas/
│       ├── secrets/
│       └── s3_ingest/
├── /app                        (Next.js frontend + API routes)
├── /workers                    (Python Lambdas)
│   ├── po_ingest/
│   ├── invoice_ingest/
│   ├── shortage_ingest/
│   ├── chargeback_ingest/
│   ├── coop_ingest/
│   ├── remittance_ingest/
│   ├── report_parser/          (S3-triggered, handles uploaded report files)
│   ├── reconciliation_engine/
│   ├── alert_evaluator/
│   └── shared/
├── /db
│   └── migrations/             (SQL migration files, forward-only)
├── /runbooks
├── /docs
│   └── decisions/              (ADRs)
└── /scripts
```

## Coding Standards

### Python
- Python 3.12, type-annotated.
- `ruff` + `black` + `mypy --strict`.
- `pydantic` for SP-API and report payload validation.
- `boto3`, `httpx`, `psycopg[pool]`.
- `structlog` with JSON output. Every log line: `vendor_id`, `run_id`, `component`, `source_system="profitshield"`.
- `pandas` is permitted for report parsing; not for anything else.
- Tests: `pytest` + `testcontainers` for Postgres integration.

### TypeScript
- TypeScript strict.
- `eslint` + `prettier`.
- Next.js 15 App Router.
- Tailwind CSS only.
- `zod` for runtime validation of all inbound data.
- `drizzle-orm` for database access. Migrations via drizzle-kit, stored in `/db/migrations`.
- Tests: `vitest` (unit), `playwright` (E2E).

### SQL
- Migrations only; no ad-hoc schema changes.
- Every table: PK, created_at, updated_at, RLS policy where tenant-scoped.
- Monetary values stored as `NUMERIC(14,2)`, never `FLOAT`.
- Currency column on every monetary table.
- Indexes on foreign keys and common query patterns; audit with `pg_stat_statements` before adding.
- No `SELECT *`.

### Git
- Conventional Commits.
- Feature branches: `feat/`, `fix/`, `infra/`, `db/`.
- Main branch always deployable to prod.
- PR descriptions: what, why, how to verify, rollback plan.

## Deployment and Environments

- **dev:** operator's laptop or ephemeral Amplify previews. Dev AWS account usage. Seeded or scrubbed vendor data only.
- **staging:** permanent mirror of prod. Connected to a sandbox vendor account for SP-API testing.
- **prod:** real customers. Changes only via CI/CD from main.

## Security

- MFA on AWS root, no root keys, IAM roles for services.
- Secrets Manager for all credentials. Rotation where supported.
- Aurora encrypted at rest, TLS in transit.
- Private subnets for Aurora and Lambda.
- CloudFront + WAF in front of the app.
- GuardDuty, Config, CloudTrail enabled account-wide.
- Authenticated Clerk session required on every API endpoint (except OAuth callbacks and marketing pages).
- Vendor data is classified sensitive. No vendor data in logs beyond `vendor_id`. No vendor data in error messages returned to frontend.
- Dollar amounts are sensitive — never log specific charge values in shared dashboards; aggregate only.

## What NOT to Build (Yet)

Without operator reconfirmation:

- Seller-side features (DD+7, FBA reimbursements). That's the other product.
- Walmart, Target, or other retailers. Amazon-only for v1.
- Native mobile apps. Responsive web only.
- API access for customers.
- White-label / multi-agency features.
- AI-generated dispute text or chat-with-your-data features.
- Direct dispute filing into Vendor Central (APDP). Ops team files manually; we surface candidates.
- Integrations to QuickBooks, Xero, NetSuite. CSV export is sufficient for v1.

## Session Workflow

When starting a Claude Code session:

1. Read this file fully.
2. Read relevant runbooks if touching existing components.
3. State the session goal in one sentence.
4. Scope the session to one component or one feature.
5. Tests before or alongside code.
6. Update this file if an architectural decision changes.
7. Write or update the runbook for any new component.
8. Commit in reviewable chunks with Conventional Commits.

## Questions to Ask the Operator When Unsure

Stop and confirm:

- Any recurring cost addition (new AWS service, new SaaS, new per-usage API).
- Anything touching vendor PII beyond `vendor_id`.
- Any architectural change to what's in this file.
- Any violation of idempotency or financial data integrity principles.
- Any design that couples ProfitShield to the DD+7 product's data.
- Any change to the shared SP-API application credentials or scopes.
- Any change to the Aurora cluster itself (adding databases is fine; changing cluster-level config requires coordination with the DD+7 product).

## Glossary (Amazon vendor-side terms)

- **1P:** First-party. Vendor sells to Amazon wholesale; Amazon resells.
- **3P:** Third-party. Seller sells on Amazon Marketplace; Amazon takes a cut.
- **Vendor Central:** Amazon's portal for 1P vendors.
- **PO:** Purchase Order Amazon sends to the vendor.
- **ASN:** Advance Shipping Notice the vendor sends to Amazon.
- **BOL:** Bill of Lading — carrier proof of pickup/delivery.
- **Remittance:** Amazon's weekly/biweekly net payment to the vendor.
- **Shortage claim:** Amazon alleges it received fewer units than the vendor invoiced.
- **Chargeback:** Compliance penalty (SIPP, SIOC, OTIF, ASN accuracy, labeling, prep).
- **SIPP:** Ships In Product Packaging. Small lightweight items that ship in their own product packaging.
- **SIOC:** Ships In Own Container. Large items that ship without an Amazon overbox.
- **OTIF:** On-Time In-Full. Delivery compliance metric.
- **Co-op:** Cooperative advertising — vendor-funded promotions, coupons, and allowances.
- **Flex Allowance:** Vendor-funded coupon redemption pool, billed retroactively.
- **Price Claim:** Amazon claims vendor overcharged vs. a competitor price; Amazon deducts the difference.
- **Net PPM:** Net Parts Per Million defect rate. Quality scorecard metric.
- **APDP:** Amazon Payment Dispute Platform — where disputes are filed.
- **VRS:** Vendor Real-time data feeds.
- **SP-API:** Selling Partner API. Amazon's API for both sellers and vendors.
- **LWA:** Login With Amazon. OAuth provider for SP-API.

## Related Products

This operator runs two other Amazon-related systems. They are isolated from ProfitShield at the application layer and must remain so:

- **RefundsManager (on-prem):** 13-year-old manual vendor recovery service. Its own SQL Server, its own codebase, its own data. ProfitShield may reference its customer list for marketing, but there is no database link, no shared table, no code import.
- **RefundsManager Cloud (DD+7 product):** Amazon 3P seller tool in a separate GitHub repo. Shares AWS infrastructure with ProfitShield but zero application-layer coupling.

## Operator Contact

Chaim is the sole decision-maker on this codebase. Jacob leads ops for the manual recovery business but is not an engineer on this codebase.
