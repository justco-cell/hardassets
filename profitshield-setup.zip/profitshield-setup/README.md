# ProfitShield

Financial intelligence platform for Amazon 1P vendors. Internal product. See CLAUDE.md for architecture and operating principles.
